require('dotenv').config()
const R = require('ramda')
const app = require('./app')
// const { mysqlPoolConnect, getConnection, testConnection }  = require('./mysql-tasks')
// const tap = require('tap-logger')
const Task = require('data.task')

const init =
  R.pipeK(
    Task.of,
    app.init(process.env.PORT || 3000)
  )(null)


init.fork(
  err => {
    if (err.errno === 'EADDRINUSE') {
      console.error('[app.listen] \nFile: server.js  \nPort already in use');
    } else {
      console.error(`Error starting server`, err)
    }
  },
  success => console.log(success.msg)
)