import * as R from 'ramda'
import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import {
  getCompositionsMedia,
  getNewsMedia,
  getFiledRecordingsMedia,
  getAnalysisMedia
} from './helpers'

Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () =>
        import(/* webpackChunkName: "about" */ './views/About.vue')
    },
    {
      path: '/works',
      name: 'works',
      component: () => import('./views/Works.vue')
    },
    {
      path: '/works/compositions',
      name: 'compositions',
      component: () => import('./views/Compositions.vue')
    },
    {
      path: '/works/compositions/:slug',
      name: 'compositions',
      props: {
        apiCall: 'getCompositions',
        contentName: 'compositions',
        pdfName: 'Score',
        pdfNamePlural: 'Scores',
        getMedia: (currentContent, fileName) =>
          getCompositionsMedia(
            R.pathOr('', ['attributes', 'slug'], currentContent),
            fileName
          )
      },
      component: () => import('./views/SingleA.vue')
    },
    {
      path: '/news',
      name: 'news',
      component: () => import('./views/News.vue')
    },
    {
      path: '/news/:slug',
      name: 'compositions',
      props: {
        apiCall: 'getNews',
        contentName: 'news',
        getMedia: (currentContent, fileName) =>
          getNewsMedia(
            R.pathOr('', ['attributes', 'slug'], currentContent),
            fileName
          )
      },
      component: () => import('./views/NewsSingle.vue')
    },
    {
      path: '/works/field-recordings',
      name: 'field-recordings',
      component: () => import('./views/FieldRecordings.vue')
    },
    {
      path: '/works/field-recordings/:slug',
      name: 'field-recordings-single',
      props: {
        apiCall: 'getFieldRecordings',
        contentName: 'fieldRecordings',
        pdfName: 'Documentation',
        pdfNamePlural: 'Documentation',
        getMedia: (currentContent, fileName) =>
          getFiledRecordingsMedia(
            R.pathOr('', ['attributes', 'slug'], currentContent),
            fileName
          )
      },
      component: () => import('./views/FieldRecordingsSingle.vue')
    },
    {
      path: '/works/analysis',
      name: 'analysis',
      component: () => import('./views/Analysis.vue')
    },
    {
      path: '/works/analysis/:slug',
      name: 'analysis-single',
      props: {
        apiCall: 'getAnalysis',
        contentName: 'analysis',
        pdfName: 'Analysis',
        pdfNamePlural: 'Analysis',
        getMedia: (currentContent, fileName) =>
          getAnalysisMedia(
            R.pathOr('', ['attributes', 'slug'], currentContent),
            fileName
          )
      },
      component: () => import('./views/AnalysisSingle.vue')
    },
    {
      path: '/works/improvisation-performance',
      name: 'improvisation-performance',
      component: () => import('./views/ImprovisationsPerformance.vue')
    }
  ]
})
