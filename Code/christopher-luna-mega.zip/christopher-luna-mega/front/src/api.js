import axios from 'axios'
import * as R from 'ramda'

const base = 'https://chlunamega.github.io/data'

const get = json => axios.get(`${base}/${json}`).then(R.path(['data']))

export default {
  homeConfig: () => get(`HomeConfig.json`),
  worksConfig: () => get(`WorksConfig.json`),
  about: () => get(`About.json`),
  news: () => get(`News.json`),
  newsConfig: () => get(`NewsConfig.json`),
  analysis: () => get(`Analysis.json`),
  fieldRecordings: () => get(`FieldRecordings.json`),
  improvisations: () => get(`Improvisation.json`),
  performances: () => get(`Performance.json`),
  compositions: () => get(`Compositions.json`),
  compositionsArchiveConfig: () => get(`CompositionsArchiveConfig.json`)
}
