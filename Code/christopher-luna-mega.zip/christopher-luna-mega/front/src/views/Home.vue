
<script>
import * as R from 'ramda'
import log from 'tap-logger' //eslint-disable-line
import { mapState } from 'vuex'
import { getHomeMedia } from '../helpers'

export default {
  mounted() {
    this.$store.dispatch('getHomeConfig')
  },
  name: 'home',
  methods: {
    getHomeMedia
  },
  computed: {
    ...mapState(['homeConfig']),
    img() {
      let img = R.pipe(
        R.pathOr([], ['homeConfig', 'images']),
        imgs => {
          let index = parseInt(Math.random() * imgs.length)
          return imgs[index]
        }
      )(this)
      return img
    }
  }
}
</script>

<template lang='pug'>
  #home.home
    .home-images(v-if="img")
      img(:src="getHomeMedia(img)")
</template>

<style lang="scss" scoped>
.home {
  height: calc(100vh - 81px);
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
}
.home-images {
  position: relative;
  top: -40px;
  margin: 0 auto;
  width: 100%;
  max-width: 500px;
}
</style>
