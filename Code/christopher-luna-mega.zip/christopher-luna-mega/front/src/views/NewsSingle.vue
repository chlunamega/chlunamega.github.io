<script>
import Single from './SingleA'
export default Single
</script>

<template lang="pug">
  #single-content.body-padding
    h1.title {{attr('title', currentContent)}}
      p.subtitle {{attr('subtitle', currentContent)}}
      p.date {{attr('showable_date', currentContent)}}
    
    .image-container
      img(v-if="has('image')"
        :src="media(currentContent, attr('image', currentContent))"
        )

    .body(v-html='currentContent.body')

    .audio(v-if="has('mp3') || has('aiff')") 
      
      p.quality quality: 
        span(v-if="has('mp3')"
          :class="quality === 'mp3' ? 'selected' : ''" 
          @click='selectQuality("mp3")'
        ) mp3
        span(v-if="has('aiff')" 
          :class="quality === 'aiff' ? 'selected' : ''" 
          @click='selectQuality("aiff")'
        ) aiff

      div.audio-track(v-if="has('mp3') && quality === 'mp3'" v-for="mp3_ in mp3s")
        p.audio-description {{mp3_.description}}
        audio(controls :src="media(currentContent, mp3_.mp3)")
      
      //- aiffs
      //- div.audio-track(v-if="has('aiff') && quality === 'aiff'")
      //-   p.audio-description {{mp3_.description}}
      //-   audio(controls :src="attr('aiff', currentContent)")
      

    .score(v-if="has('pdf')") 
      p(v-if='pdfs.length === 1') View score:
      p(v-if='pdfs.length > 1') View scores:
        div(v-for='pdf in pdfs')
          a(target="_blank" :href='media(pdf.pdf)') {{pdf.description}}
</template>
