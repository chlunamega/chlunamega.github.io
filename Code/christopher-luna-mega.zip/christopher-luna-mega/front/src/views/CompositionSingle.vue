<script>
import Single from './SingleA'
export default Single
</script>