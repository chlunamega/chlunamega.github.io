import * as R from 'ramda'
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import {
  getAboutMedia,
  getHomeMedia,
  getWorksMedia,
  getNewsMedia2,
  getPublicMedia,
  getCompositionsMedia,
  getNewsMedia,
  getFiledRecordingsMedia,
  $SepartedStringIntoArr
} from './helpers'
import log from 'tap-logger' //eslint-disable-line

Vue.config.productionTip = false

Vue.mixin({
  data() {
    return {
      ghMedia: (slug, media) =>
        `https://chlunamega.github.io/public/${slug}/${media}`
    }
  },
  methods: {
    log,
    $SepartedStringIntoArr,
    getAboutMedia,
    getHomeMedia,
    getWorksMedia,
    getNewsMedia2,
    getPublicMedia,
    getCompositionsMedia,
    getNewsMedia,
    getFiledRecordingsMedia,
    attr: (attr, obj) => R.path(['attributes', attr], obj)
  }
})
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')