var ManifestPlugin = require("webpack-manifest-plugin")
console.log("runs vue config")

module.exports = {
  configureWebpack: {
    plugins: [new ManifestPlugin()]
  },
  chainWebpack: config => {
    config.optimization.splitChunks(false)
  }
}
