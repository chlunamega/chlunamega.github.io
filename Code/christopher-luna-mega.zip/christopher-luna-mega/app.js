const path = require('path')
const express = require('express')
const Task = require('data.task')
const http = require('http')
const R = require('ramda')
const tap = require('tap-logger')
const {
  curry
} = R
const {
  Maybe,
  either
} = require('crocks')
const {
  Just,
  Nothing
} = Maybe

const versionedAssets = require('./front/dist/manifest.json')

const safeHead = x => x && x[0] ? Just(x[0]) : Nothing()

const app = express()
const server = http.createServer(app)

const init = curry((port, db) => {

  app.set('view engine', 'pug')
  app.set('views', path.join(__dirname, '/views'));

  app.use('/js', express.static(__dirname + '/front/dist/js'))
  app.use('/css', express.static(__dirname + '/front/dist/css'))
  app.use('/img', express.static(__dirname + '/front/dist/img'))
  app.use('/media', express.static(__dirname + '/front/dist/img'))
  app.use('/public', express.static(__dirname + '/public'))
  app.use((req, res, next) => {
    let baseUrl = process.env.NODE_ENV === 'development' ?
      '//' + req.headers.host :
      '//' + req.headers.host

    res.locals.baseUrl = baseUrl

    res.locals.mainClientJS = process.env.WEBPACK === 'true' ?
      `http://localhost:${process.env.WEBPACK_PORT || 8080}/public/build/bundle.js` :
      `${res.locals.baseUrl}${versionedAssets['app.js']}`

    res.locals.mainClientCSS = `${res.locals.baseUrl}${versionedAssets['app.css']}`
    next();
  })
  app.use((req, res, next) => { //File not Found 404
    tap.id(req.originalUrl)
    if (
      req.originalUrl.indexOf('/public') === 0
    ) {
      res.status(404).send('Not Found')
      return
    }
    next()
  })

  //SEO
  const seoBase = {
    title: 'Christopher Luna Mega | Composer',
    description: 'Music Composer',
    image: {
      url: res => res.locals.baseUrl + '/public/seo.jpeg',
      width: 1024,
      height: 768
    }
  }

  app.get('*', (req, res) => {
    let openGraph = {
      url: res.locals.baseUrl + req.url,
      title: seoBase.title,
      description: seoBase.description,
      image: {
        url: seoBase.image.url(res),
        width: seoBase.image.width,
        height: seoBase.image.height,
      }
    }

    res.render('index', {
      openGraph,
    })
  })


  return new Task((reject, resolve) => {
    server.listen(port, () => {
      resolve({
        msg: 'Chluna server is listening on port ' + port + '!',
        app,
        server
      })
    }).on('error', reject);
  })
})


module.exports = {
  app,
  init
}